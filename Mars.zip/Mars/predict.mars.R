# predict()
predict.mars <- function(object, ...){
  coe<-na.omit(object$coefficients)
  pre <-object$B %*% coe
  return(pre)
}

