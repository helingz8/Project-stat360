# summary()
summary.mars <- function(object,...){
  cat("Call:\n")
  print(object$call)
  cat("\nResiduals:\n")
  print(object$residual)
  cat("\nCoefficients:\n")
  print(object$coefficient)
}

