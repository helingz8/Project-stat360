# anova()
anova.mars <- function(object, ...){
  coff <- object$coefficient
  coff <- data.frame(coff)
  coff_name <- rownames(coff)
  for (i in 1:length(coff_name)){
    cat(paste0("Coefficient of ", coff_name[i], " is ", coff[i,1], "\n"))
  }
  aov(object)
}


 