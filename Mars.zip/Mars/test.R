source("/Users/zhangheling/Desktop/Mars/mars.R")
source("/Users/zhangheling/Desktop/Mars/anova.mars.R")
source("/Users/zhangheling/Desktop/Mars/plot.mars.R")
source("/Users/zhangheling/Desktop/Mars/predict.mars.R")
source("/Users/zhangheling/Desktop/Mars/print.mars.R")
source("/Users/zhangheling/Desktop/Mars/summary.mars.R")

library(ISLR)
# given data
load("/Users/zhangheling/Desktop/Mars/marstestdata.rda")
mc <- mars.control(Mmax=10)
mout1 <- mars(y ~ .,data=marstestdata,control=mc)
anova(mout1)
plot(mout1)
predict(mout1)
print(mout1)
summary(mout1)


# first data
data2<-read.csv("/Users/zhangheling/Desktop/Mars/data2.csv", header = FALSE)
mc <- mars.control(Mmax=10)
Lenmout2 <- mars(V1 ~ .,data=data2,control=mc)
anova(mout2)
plot(mout2)
predict(mout2)
print(mout2)
summary(mout2)

#second data
data1<-read.csv("/Users/zhangheling/Desktop/Mars/data1.csv", header = TRUE)
mc <- mars.control(Mmax=10)
mout3 <- mars(Total_Length ~ .,data=data1,control=mc)
anova(mout3)
plot(mout3)
predict(mout3)
print(mout3)
summary(mout3)