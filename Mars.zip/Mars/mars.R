# mars() function (Data structure)
mars <- function(formula, data, control=NULL,...){
  cc <- match.call()
  mf <- model.frame(formula, data)
  y <- model.response(mf)
  mt <- attr(mf, "terms")
  x <- model.matrix(mt,mf)
  if(is.null(control))
    control <- mars.control()
  fwd <- fwd_stepwise(y,x,control)
  bwd <- bwd_stepwise(fwd, control)
  fit.model <- lm(y~., data=data.frame(y=y, bwd$B))
  out <- c(list(call=cc, formula=formula, y=y, B=bwd$B, splits=bwd$splits), fit.model)
  class(out) <- c("mars", class(fit.model))
  out
}

# fwd_stepwise()
fwd_stepwise <- function(y,x, control=mars.control()){
  l<-length(y)
  n<-ncol(x)
  B<-matrix(1, nrow=l, ncol=1)
  splits<-list(data.frame(m=0, v=0, s=NA, t=NA))
  M<-1
  
  while((M <=control$Mmax)){
    if(control$trace==TRUE)
      cat("M", M, "\n")
    lof_b<-Inf
    for (m in 1:M){
      s_var <- setdiff(1:n, splits[[m]]$v)
      if(control$trace==TRUE)
        cat("M", M, "\n")
      for(v in s_var){
        tt<-split_points(x[,v], B[,m])
        for (t in tt){
          Bnew=data.frame(B[,(1:M)[-m]], Btem1=B[,m]*h(x[,v], 1, t), Btem2=B[,m]*h(x[,v], -1, t))
          gdat=data.frame(y=y, Bnew)
          lof=LOF(y~., gdat, control)
          if (lof<lof_b){
            lof_b=lof
            split_best=c(m=m, v=v, t=t)
          }
        }
      }
    }
    
    m=split_best["m"]
    v=split_best["v"]
    t=split_best["t"]
    
    B=cbind(B, B[,m]*h(x[,v], 1, t))
    B=cbind(B, B[,m]*h(x[,v], -1, t))
    splits_l=rbind(splits[[m]], c(m=m, v=v, s=-1, t=t))
    splits_r=rbind(splits[[m]], c(m=m, v=v, s=1, t=t))
    splits=c(splits, list(splits_l), list(splits_r))
    M=M+2
  }
  return(list(y=y, B=B, splits=splits))
}


# bwd_stepwise()
bwd_stepwise <- function(fwd,control){
  Mmax <- ncol(fwd$B)-1
  J_star <- 2:(Mmax+1)
  K_star <- J_star
  dat <- data.frame(y=fwd$y,fwd$B)
  lof_star <- LOF(y~.-1,dat,control)
  for (M in (Mmax+1):2){
    b <- Inf
    L <- K_star
    if(control$trace) cat("L:",L,"\n")
    for (m in L) {
      K <- setdiff(L,m)
      dat <- data.frame(y=fwd$y,fwd$B[,K])
      lof <- LOF(y~.,dat,control)
      if(control$trace) cat("M:K:lof",M,":",K,":",lof,"\n")
      if(lof < b) {
        b <- lof
        K_star <- K
      }
      if(lof < lof_star){
        lof_star <- lof
        J_star <- K
      }
    }
  }
  J_star <- c(1,J_star)
  return(list(y=fwd$y,B=fwd$B[,J_star],splits=fwd$splits[J_star]))
}



# Constructer, validator ans helper for class mars.control
new_mars.control <- function(control){
  structure(control, class="mars.control")
}


validate_mars.control <- function(control){
  stopifnot(is.integer(control$Mmax), is.numeric(control$d),
            is.logical(control$trace))
  if(control$Mmax<2){
    warning("Mman must be >=2; Reset it to 2")
    control$Mman <- 2}
  if(control$Mmax %% 2>0){
    control$Mmax <- 2*ceiling(control$Mmax/2)
    warning(paste("Mmax should be an even integer. Reset it ", control$Mmax))
  }
  control
}

mars.control <- function(Mmax=2, d=3, trace=FALSE){
  Mmax <- as.integer(Mmax)
  control <- list(Mmax=Mmax, d=d, trace=trace)
  control <- validate_mars.control(control)
  new_mars.control(control)
}

h = function(x,s,t){ 
  pmax(0, s*(x-t))
}

init_B <- function(N,Mmax) {
  B <- data.frame(matrix(NA,nrow=N,ncol=(Mmax+1)))
  B[,1] <- 1
  names(B) <- c("B0",paste0("B",1:Mmax))
  return(B)
}

LOF <- function(form,data,control){
  N = nrow(data)
  ff = lm(form,data)
  Rss = sum(residuals(ff)^2)
  M = length(coef(ff))-1
  C_M = sum(ff$hat)+control$d*M
  return(Rss*N/(N-C_M)^2)
}

split_points <- function(xv,Bm) {
  out <- sort(unique(xv[Bm>0]))
  out <- out[-length(out)]
  return(out)
}
