# plot()
plot.mars <- function(object, ...){
  par(mfcol=c(2,1))
  plot(x=object$fitted, y=object$y, main=deparse(object$call), 
       xlab="fitted value", ylab="y value")
  qqnorm(unlist(residuals(object)))
  qqline(unlist(residuals(object)))
}

