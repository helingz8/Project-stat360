# print()
print.mars <- function(object,...){
  cat("mars coffeicients:\n")
  print(object$coefficients)
}
